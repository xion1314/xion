package com.sotaapps.activities

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.ProgressDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.gson.Gson
import com.sotaapps.R
import com.sotaapps.connection.API
import com.sotaapps.model.User
import com.sotaapps.model.Wisata
import com.sotaapps.utils.FileUtils
import id.zelory.compressor.Compressor
import kotlinx.android.synthetic.main.activity_add_image.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import java.util.*

class AddImageActivity : AppCompatActivity() {
    private val dataWisata = Wisata()
    var fileUploads = Array<AddImageActivity.FileUpload?>(1, { null })
    private val GALLERY_INTENT_CALLED: Int = 1
    private val GALLERY_KITKAT_INTENT_CALLED: Int = 2
    private var dataUri: Uri? = null
    private val MY_PERMISSIONS_REQUEST_EXTERNAL_STORAGE: Int = 100
    lateinit var editTextToUploadSelectedIndex: java.util.HashMap<Int, EditText>
    lateinit var imageViewToUploadSelectedIndex: java.util.HashMap<Int, ImageView>
    lateinit var fieldNameToUploadSelectedIndex: java.util.HashMap<Int, String>
    var uploadSelectedIndex = 0
    lateinit var textViewtToUploadSelectedIndex: HashMap<Int, TextView>


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_image)


        tv_tambah_foto.setOnClickListener {
            uploadSelectedIndex = 0
            if (checkPermission()) {
                getFileChooserIntent()
            }
        }

        imageViewToUploadSelectedIndex = hashMapOf(
            0 to imageview
        )

        fieldNameToUploadSelectedIndex = hashMapOf(
            0 to "image"
        )

        textViewtToUploadSelectedIndex = hashMapOf(
            0 to img_path
        )

        btnSimpan.setOnClickListener{
            insertImage()
        }

    }

    fun isValid() : Boolean {
        var valid : Boolean = true

        if(edt_judul.text.toString() == null){
            Toast.makeText(this@AddImageActivity, "Judul tidak boleh kosong!", Toast.LENGTH_LONG).show()
            valid = false
        } else if(edt_deskripsi.text.toString() == null){
            Toast.makeText(this@AddImageActivity, "Deskripsi tidak boleh kosong!", Toast.LENGTH_LONG).show()
            valid = false

        }else if(dataUri == null){
            Toast.makeText(this@AddImageActivity, "Anda belum menambahkan foto!", Toast.LENGTH_LONG).show()
            valid = false
        }

        return valid
    }

    fun insertImage(){
        if (isValid()) {
            val progressDialog = ProgressDialog(this)
            progressDialog.setMessage("Menyimpan...")
            progressDialog.show()
            progressDialog.setCancelable(false)

            val savedUser = Gson()
                .fromJson(
                    this@AddImageActivity
                        .getSharedPreferences(LoginActivity.MY_LOGIN_PREF, Context.MODE_PRIVATE)
                        .getString(LoginActivity.MY_LOGIN_PREF_KEY, ""), User::class.java
                )

            dataWisata.createdBy = savedUser.id
            val desc = edt_deskripsi.text.toString()
            val judul = edt_judul.text.toString()
            dataWisata.deskripsi = desc
            dataWisata.judul = judul

            val compileFileUploads = ArrayList<FileUpload>()
            fileUploads.forEach { if (it != null) compileFileUploads.add(it) }
            API.insertWisata(dataWisata, compileFileUploads).enqueue(object : Callback<Wisata> {
                override fun onResponse(call: Call<Wisata>, response: Response<Wisata>) {
                    if (response.code() == 200) {
                        progressDialog.dismiss()
                        Toast.makeText(
                            this@AddImageActivity,
                            "Berhasil tambah data",
                            Toast.LENGTH_LONG
                        ).show()
                        finish()
                    } else {
                        progressDialog.dismiss()
                        Toast.makeText(this@AddImageActivity, "Cek Koneksi Anda", Toast.LENGTH_LONG)
                            .show()
                    }
                }

                override fun onFailure(call: Call<Wisata>, t: Throwable) {
                    progressDialog.dismiss()
                    Toast.makeText(this@AddImageActivity, "Cek Koneksi Anda", Toast.LENGTH_LONG)
                        .show()
                }
            })
        }
    }

    @SuppressLint("NewApi")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK) return

        data?.let {
            dataUri = it.data
            val thumbnail = MediaStore.Images.Media.getBitmap(
                contentResolver, dataUri
            )

            if (requestCode == GALLERY_KITKAT_INTENT_CALLED) {
                val takeFlags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                // Check for the freshest data.
                if (dataUri != null) {
                    this.contentResolver.takePersistableUriPermission(dataUri!!, takeFlags)
                }
            }

            val type = contentResolver.getType(dataUri!!)
            val filePath = FileUtils.getPath(this, dataUri)
            val extension = FileUtils.getExtension(filePath)
            val fileName = FileUtils.getFileName(filePath)
            val receivableExtension = arrayOf(".png", ".jpg", "jpeg")
            if (extension != null && filePath != null && receivableExtension.contains(extension.toLowerCase())) {
                try {
                    val bitmap = Compressor(this@AddImageActivity)
                        .setMaxWidth(500)
                        .setMaxHeight(340)
                        .setQuality(75)
                        .setCompressFormat(Bitmap.CompressFormat.WEBP)
                        .compressToBitmap(File(filePath))

                    fileUploads[uploadSelectedIndex] = FileUpload(bitmap, fileName, type!!, fieldNameToUploadSelectedIndex[uploadSelectedIndex])
                    imageViewToUploadSelectedIndex[uploadSelectedIndex]?.setImageBitmap(bitmap)
                    textViewtToUploadSelectedIndex[uploadSelectedIndex]?.text = fileName
                } catch (e: Exception) {
                    e.printStackTrace()
                }

                layout_img.visibility = View.GONE
                tv_tambah_foto.visibility = View.GONE
                imageview.visibility = View.VISIBLE
                imageview.setImageBitmap(thumbnail)


            }else{
                Toast.makeText(this@AddImageActivity, "Image Only", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun checkPermission() : Boolean {
        if(Build.VERSION.SDK_INT>=android.os.Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this@AddImageActivity, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE)) {
                    val alertBuilder = android.app.AlertDialog.Builder(this@AddImageActivity)
                    alertBuilder.setCancelable(true)
                    alertBuilder.setTitle("Permission necessary")
                    alertBuilder.setMessage("Read access to storage is needed!")
                    alertBuilder.setPositiveButton(android.R.string.yes, DialogInterface.OnClickListener { dialog, which ->
                        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), MY_PERMISSIONS_REQUEST_EXTERNAL_STORAGE)
                    })
                    alertBuilder.create().show()
                } else {
                    ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), MY_PERMISSIONS_REQUEST_EXTERNAL_STORAGE)
                }
                return false
            } else {
                return true
            }
        } else {
            return true
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == MY_PERMISSIONS_REQUEST_EXTERNAL_STORAGE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getFileChooserIntent()
            }
        }
    }

    private fun getFileChooserIntent() {

        if (Build.VERSION.SDK_INT < 19) {
            val intent = Intent()
            intent.type = "/"
            intent.action = Intent.ACTION_GET_CONTENT
            startActivityForResult(Intent.createChooser(intent, "Select Picture"), GALLERY_INTENT_CALLED)
        } else {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
            intent.addCategory(Intent.CATEGORY_OPENABLE)
            intent.type = "*/*"
            startActivityForResult(intent, GALLERY_KITKAT_INTENT_CALLED)
        }
    }

    inner class FileUpload(var bitmap: Bitmap, var fileName: String, var type: String, var fieldName: String? = "image")

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}