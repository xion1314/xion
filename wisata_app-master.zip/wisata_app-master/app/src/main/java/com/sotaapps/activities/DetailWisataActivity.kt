package com.sotaapps.activities

import android.app.ProgressDialog
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.sotaapps.R
import com.sotaapps.connection.API
import com.sotaapps.model.Wisata
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_detail_wisata.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailWisataActivity : AppCompatActivity() {

    var mActionBarToolbar: Toolbar? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_wisata)

        getData()

    }

    fun getData() {
        val progressDialog = ProgressDialog(this@DetailWisataActivity)
        progressDialog.setMessage("Memuat data...")
        progressDialog.show()
        progressDialog.setCancelable(false)
        val extras = intent.extras
        val id = extras?.getString("ID_WISATA");

        API.getDetailWisara(id)
            .enqueue(object : Callback<ArrayList<Wisata>> {

                override fun onResponse(
                    call: Call<ArrayList<Wisata>>,
                    response: Response<ArrayList<Wisata>>
                ) {
                    if (response.code() == 200) {

                        txtJudul.setText(response.body()?.get(0)?.judul)
                        txtDeskripsi.setText(response.body()?.get(0)?.deskripsi)

                        Picasso.with(this@DetailWisataActivity)
                            .load(API.baseURLImage + response.body()?.get(0)?.foto)
                            .into(ivGambarWisata)

                        progressDialog.dismiss()

                    } else {
                        Toast.makeText(
                            this@DetailWisataActivity,
                            "Gagal memuat data",
                            Toast.LENGTH_SHORT
                        ).show()
                        progressDialog.dismiss()
                    }

                }

                override fun onFailure(call: Call<ArrayList<Wisata>>, throwable: Throwable) {
                    Toast.makeText(
                        this@DetailWisataActivity,
                        "Tidak tersambung dengan server. Periksa koneksi anda",
                        Toast.LENGTH_SHORT
                    ).show()
                    progressDialog.dismiss()

                }
            })

    }


    companion object
}