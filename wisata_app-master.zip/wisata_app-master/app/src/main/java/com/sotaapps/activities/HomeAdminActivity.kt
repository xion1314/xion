package com.sotaapps.activities

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.PopupMenu
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import com.sotaapps.R
import com.sotaapps.connection.API
import com.sotaapps.model.User
import kotlinx.android.synthetic.main.activity_home_admin.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class HomeAdminActivity : AppCompatActivity() {
    var mId:String = "AA"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_admin)

        getDataPengunjung()

        val savedUser = Gson().fromJson(getSharedPreferences(LoginActivity.MY_LOGIN_PREF, Context.MODE_PRIVATE).getString(
            LoginActivity.MY_LOGIN_PREF_KEY, ""), User::class.java)
        val namaUser = savedUser.nama
        mId = savedUser.id.toString()

        name_user.text = "Hi, " + namaUser

        card_pengunjung.setOnClickListener {
            startActivity(Intent(this@HomeAdminActivity, IndexDataPengunjungActivity::class.java))
        }

        img_pengunjung.setOnClickListener {
            startActivity(Intent(this@HomeAdminActivity, IndexDataPengunjungActivity::class.java))
        }

        card_image.setOnClickListener {
            startActivity(Intent(this@HomeAdminActivity, AddImageActivity::class.java))
        }

        txt_image.setOnClickListener {
            startActivity(Intent(this@HomeAdminActivity, AddImageActivity::class.java))
        }

        arrow_image.setOnClickListener{
            startActivity(Intent(this@HomeAdminActivity, AddImageActivity::class.java))
        }

        card_excel.setOnClickListener {
            startActivity(Intent(this@HomeAdminActivity, ReportActivity::class.java))
        }

        btn_go_userlist.setOnClickListener{
            startActivity(Intent(this@HomeAdminActivity, activity_userlist::class.java))
        }

        txt_excel.setOnClickListener {
            startActivity(Intent(this@HomeAdminActivity, ReportActivity::class.java))
        }

        arrow_excel.setOnClickListener{
            startActivity(Intent(this@HomeAdminActivity, ReportActivity::class.java))
        }

        more.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View) {
                val popup = PopupMenu(this@HomeAdminActivity, more)
                popup.menuInflater.inflate(R.menu.main, popup.menu)
                popup.setOnMenuItemClickListener(object : PopupMenu.OnMenuItemClickListener {
                    override fun onMenuItemClick(item: MenuItem): Boolean {
                        if (item.itemId === R.id.action_logout) {
                            val preferences = this@HomeAdminActivity.getSharedPreferences(
                                LoginActivity.MY_LOGIN_PREF,
                                Context.MODE_PRIVATE
                            )
                            preferences!!.edit().remove(LoginActivity.MY_LOGIN_PREF_KEY).apply()
                            val i = Intent(this@HomeAdminActivity, LoginActivity::class.java)
                            startActivity(i)
                            finish()
                        }
                        else if (item.itemId === R.id.action_menu_user) {
                            val i = Intent(this@HomeAdminActivity, MenuUserActivity::class.java)
                            i.putExtra("mode", mId)
                            startActivity(i)
                        }
                        return false
                    }
                })
                popup.show()
            }
        })


    }

    fun getDataPengunjung(){
        API.getAllUser()
            .enqueue(object : Callback<ArrayList<User>> {

                override fun onResponse(
                    call: Call<ArrayList<User>>,
                    response: Response<ArrayList<User>>
                ) {
                    if (response.code() == 200) {
                        count_pengunjung.text = response.body()!!.size.toString()

                    } else {
                        Toast.makeText(
                            this@HomeAdminActivity,
                            "Gagal memuat data",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                }

                override fun onFailure(call: Call<ArrayList<User>>, throwable: Throwable) {
                    Toast.makeText(
                        this@HomeAdminActivity,
                        "Tidak tersambung dengan server. Periksa koneksi anda",
                        Toast.LENGTH_SHORT
                    ).show()

                }
            })
    }

    override fun onBackPressed() {
        val dialog = AlertDialog.Builder(this@HomeAdminActivity)
        dialog.setTitle("Sota Apps")
            .setMessage("Apakah Anda ingin keluar dari aplikasi ini?")
            .setPositiveButton("Ya") { dialog, which ->
                super.onBackPressed()
                finish()
            }
            .setNegativeButton("Tidak", { paramDialogInterface, paramInt -> })
        dialog.show()
    }
}