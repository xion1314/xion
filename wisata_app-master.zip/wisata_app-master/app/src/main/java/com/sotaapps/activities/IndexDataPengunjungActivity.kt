package com.sotaapps.activities

import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.sotaapps.R
import com.sotaapps.adapter.IndexDataPengunjungAdapter
import com.sotaapps.connection.API
import com.sotaapps.model.User
import com.sotaapps.utils.RecyclerItemClickListener
import kotlinx.android.synthetic.main.activity_index_data_pengunjung.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class IndexDataPengunjungActivity : AppCompatActivity() {

    private lateinit var linearLayoutManager: LinearLayoutManager
    var datas: ArrayList<User>? = null
    var tempDatas: ArrayList<User>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_index_data_pengunjung)

        linearLayoutManager = LinearLayoutManager(this)
        rvIndexPengunjung.layoutManager = linearLayoutManager

        getData()

        fbTambahUSer.setOnClickListener {
            val i =
                Intent(this@IndexDataPengunjungActivity, TambahDataPengunjungActivity::class.java)
            startActivity(i)
        }

        rvIndexPengunjung!!.addOnItemTouchListener(RecyclerItemClickListener(this, RecyclerItemClickListener.OnItemClickListener { view, position ->
            val intent = Intent(this, MenuUserActivity::class.java)
            val prefs = this?.getSharedPreferences("X", Context.MODE_PRIVATE)
            val editor = prefs?.edit()
            editor?.putString("idUser", datas!![position].userId)
            editor?.apply()
            intent.putExtra("mode", datas!![position].userId)
            startActivity(intent)
        }))

    }

    fun getData() {
        val progressDialog = ProgressDialog(this@IndexDataPengunjungActivity)
        progressDialog.setMessage("Memuat data...")
        progressDialog.show()
        progressDialog.setCancelable(false)
        API.getAllUser()
            .enqueue(object : Callback<ArrayList<User>> {

                override fun onResponse(
                    call: Call<ArrayList<User>>,
                    response: Response<ArrayList<User>>
                ) {
                    if (response.code() == 200) {
                        datas = response.body()
                        tempDatas = datas
                        rvIndexPengunjung!!.setHasFixedSize(true)
                        rvIndexPengunjung!!.layoutManager =
                            LinearLayoutManager(this@IndexDataPengunjungActivity)

                        rvIndexPengunjung!!.adapter = IndexDataPengunjungAdapter(tempDatas!!)

                        progressDialog.dismiss()

                    } else {
                        Toast.makeText(
                            this@IndexDataPengunjungActivity,
                            "Gagal memuat data",
                            Toast.LENGTH_SHORT
                        ).show()
                        progressDialog.dismiss()
                    }

                }

                override fun onFailure(call: Call<ArrayList<User>>, throwable: Throwable) {
                    Toast.makeText(
                        this@IndexDataPengunjungActivity,
                        "Tidak tersambung dengan server. Periksa koneksi anda",
                        Toast.LENGTH_SHORT
                    ).show()
                    progressDialog.dismiss()

                }
            })

    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}