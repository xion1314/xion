package com.sotaapps.activities

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import com.sotaapps.R
import com.sotaapps.connection.API
import com.sotaapps.model.User
import kotlinx.android.synthetic.main.activity_login.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val savedUser = Gson().fromJson(getSharedPreferences(MY_LOGIN_PREF, Context.MODE_PRIVATE).getString(MY_LOGIN_PREF_KEY, ""), User::class.java)
        if (savedUser != null && savedUser.status == "success"){
            val title = savedUser.groupTitle
            if (title.equals("User")){
                startActivity(Intent(this@LoginActivity, MenuUtamaUserActivity::class.java))
                finish()
            } else {
                startActivity(Intent(this@LoginActivity, HomeAdminActivity::class.java))
                finish()
            }
        }

        tv_signup.setOnClickListener {
            startActivity(Intent(this@LoginActivity, SignupActivity::class.java))
            finish()
        }

        btnLogin.setOnClickListener {
            btnLogin.visibility = View.INVISIBLE
            progressBar.visibility = View.VISIBLE
            val usernameEditText = edt_username.text.toString()
            val passwordEditText = edt_password.text.toString()

            if (usernameEditText.equals("") || passwordEditText.equals("")) {
                Toast.makeText(this, "Username & password harus diisi", Toast.LENGTH_SHORT).show()
                btnLogin.visibility = View.VISIBLE
                progressBar.visibility = View.INVISIBLE
            } else {
                val dataUser = User()
                dataUser.username = edt_username.text.toString()
                dataUser.password = edt_password.text.toString()

                API.doLogin(dataUser).enqueue(object : Callback<User> {
                    override fun onResponse(call: Call<User>, response: Response<User>) {
                        if (response.code() == 200) {
                            val user = response.body()

                            // Save data login
                            getSharedPreferences(MY_LOGIN_PREF, Context.MODE_PRIVATE).edit()
                                .putString(MY_LOGIN_PREF_KEY, Gson().toJson(user)).apply()

                            if (user?.status != "success") {
                                Toast.makeText(this@LoginActivity, user?.status, Toast.LENGTH_LONG)
                                    .show()
                                btnLogin.visibility = View.VISIBLE
                                progressBar.visibility = View.INVISIBLE
                            } else {
                                val savedUser = Gson().fromJson<User>(
                                    this@LoginActivity.getSharedPreferences(
                                        LoginActivity.MY_LOGIN_PREF,
                                        Context.MODE_PRIVATE
                                    ).getString(LoginActivity.MY_LOGIN_PREF_KEY, ""),
                                    User::class.java
                                )
                                val title = savedUser.groupTitle

                                if (title.equals("User")) {
                                    startActivity(
                                        Intent(
                                            this@LoginActivity,
                                            MenuUtamaUserActivity::class.java
                                        )
                                    )
                                    finish()

                                } else {
                                    startActivity(
                                        Intent(
                                            this@LoginActivity,
                                            HomeAdminActivity::class.java
                                        )
                                    )
                                    finish()
                                }

                            }

                        } else {
                            Toast.makeText(
                                this@LoginActivity,
                                "Username atau password salah",
                                Toast.LENGTH_LONG
                            ).show()
                            btnLogin.visibility = View.VISIBLE
                            progressBar.visibility = View.INVISIBLE
                        }
                    }

                    override fun onFailure(call: Call<User>, t: Throwable) {
                        Toast.makeText(
                            this@LoginActivity,
                            "Tidak terhubung dengan server. periksa koneksi anda",
                            Toast.LENGTH_LONG
                        ).show()
                        btnLogin.visibility = View.VISIBLE
                        progressBar.visibility = View.INVISIBLE
                    }
                })
            }

        }
    }

    companion object {
        const val MY_LOGIN_PREF = "myLoginPref"
        const val MY_LOGIN_PREF_KEY = "loginPrefKey"
    }
}

