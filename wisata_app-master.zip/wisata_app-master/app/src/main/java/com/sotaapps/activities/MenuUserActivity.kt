package com.sotaapps.activities

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.ProgressDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StrictMode
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.gson.Gson
import com.sotaapps.R
import com.sotaapps.connection.API
import com.sotaapps.connection.API.baseURLImage
import com.sotaapps.model.User
import com.sotaapps.utils.FileUtils
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_add_image.*
import kotlinx.android.synthetic.main.activity_menu_user.*
import kotlinx.android.synthetic.main.activity_menu_user.btnSimpan
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

class MenuUserActivity : AppCompatActivity() {
    val REQUEST_IMAGE_CAPTURE = 100
    val REQUEST_CODE_PERMISSIONS = 101
    val REQUEST_KTP_CAPTURE:Int = 102
    var idUser: String = ""
    private val userModel = User()
    var fileUploads = Array<File?>(2, { null })
    private val GALLERY_INTENT_CALLED: Int = 1
    private val GALLERY_KITKAT_INTENT_CALLED: Int = 2
    private val MODE_FROM_ADMIN: Int = 301;
    private var mode_pick: Int = 0
    private var dataUri: Uri? = null
    private var fileKTP:File? = null
    private val MY_PERMISSIONS_REQUEST_EXTERNAL_STORAGE: Int = 100
    lateinit var editTextToUploadSelectedIndex: java.util.HashMap<Int, EditText>
    lateinit var imageViewToUploadSelectedIndex: java.util.HashMap<Int, ImageView>
    lateinit var fieldNameToUploadSelectedIndex: java.util.HashMap<Int, String>
    var uploadSelectedIndex = 0
    lateinit var textViewtToUploadSelectedIndex: HashMap<Int, TextView>

    var mActionBarToolbar: Toolbar? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu_user)
        setContext(this!!.applicationContext)

        val policy =
            StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)

        edtGender.isEnabled = false
        edtAsalNegara.isEnabled = false


        val i_ = intent
        if(null != i_){
            idUser= i_.getStringExtra("mode")!!
        }
        getData()
        btnSimpan.setOnClickListener {
            saveData()
        }

        user_camera_floating_button.setOnClickListener {
            uploadSelectedIndex = 0
            if (checkPermission()) {
                getFileChooserIntent()
            }
        }
        btn_uploadKTP.setOnClickListener(){
            val mI:Intent = Intent(this@MenuUserActivity, activity_goCapture::class.java)
            mI.putExtra("mode",REQUEST_KTP_CAPTURE)
            startActivityForResult(Intent(this@MenuUserActivity, activity_goCapture::class.java), REQUEST_KTP_CAPTURE)
        }

        imageViewToUploadSelectedIndex = hashMapOf(
            0 to imageview
        )

        fieldNameToUploadSelectedIndex = hashMapOf(
            0 to "image"
        )

        textViewtToUploadSelectedIndex = hashMapOf(
            0 to img_path
        )
    }

    fun getData() {
        val progressDialog = ProgressDialog(this@MenuUserActivity)
        progressDialog.setMessage("Memuat data...")
        progressDialog.show()
        progressDialog.setCancelable(false)

        var savedUser:User = User()
        var group:String?
        if(idUser.equals("A")){
            savedUser = Gson().fromJson<User>(
                this@MenuUserActivity.getSharedPreferences(
                    LoginActivity.MY_LOGIN_PREF,
                    Context.MODE_PRIVATE
                ).getString(LoginActivity.MY_LOGIN_PREF_KEY, ""), User::class.java
            )
            group = savedUser.groupTitle
        }
        else{
            group = "Admin"
        }

        if (group.equals("User")){
            val id = savedUser.id
            API.getUser(id)
                .enqueue(object : Callback<ArrayList<User>> {

                    override fun onResponse(
                        call: Call<ArrayList<User>>,
                        response: Response<ArrayList<User>>
                    ) {
                        if (response.code() == 200) {
                            val mUser:User = response.body()!![0]

                            edtNama.setText(mUser.nama)
                            edtUsername.setText(mUser.username)
                            edtPassword.setText(mUser.password)
                            if (mUser.keperluan.isNullOrEmpty()){
                                edtKeperluan.setText("-")

                            } else {
                                edtKeperluan.setText(mUser.keperluan)

                            }
                            edtEmail.setText(mUser.email)
                            edtGender.setText(mUser.jenisKelamin)
                            edtAsalNegara.setText(mUser.CountryOrigin)
                            edtNoHp.setText(mUser.noHp)
                            val foto = mUser.foto_diri
                            val fotoKtp = mUser.foto_ktp

                            if (foto != null){
                                Picasso.with(user_profile_photo.context)
                                    .load(API.baseURLImage + mUser.foto_diri)
                                    .into(user_profile_photo)
                                val mFile = createImageFile()

                                fileUploads[0] = getBitmapFromURL(API.baseURLImage + mUser.foto_diri, mFile!!)

                                user_profile_photo_default.visibility = View.GONE
                                user_profile_photo.visibility = View.VISIBLE
                            }
                            if (fotoKtp != null){
                                Picasso.with(vw_imgKtp.context)
                                    .load(API.baseURLImage + mUser.foto_ktp)
                                    .into(vw_imgKtp)
                                val mFile = createImageFile()
                                fileUploads[1] = getBitmapFromURL(API.baseURLImage + mUser.foto_ktp, mFile!!)
                            }
                            progressDialog.dismiss()

                        } else {
                            Toast.makeText(
                                this@MenuUserActivity,
                                "Gagal memuat data",
                                Toast.LENGTH_SHORT
                            ).show()
                            progressDialog.dismiss()
                        }
                    }

                    override fun onFailure(call: Call<ArrayList<User>>, throwable: Throwable) {
                        Toast.makeText(
                            this@MenuUserActivity,
                            "Tidak tersambung dengan server. Periksa koneksi anda",
                            Toast.LENGTH_SHORT
                        ).show()
                        progressDialog.dismiss()

                    }
                })

        } else if (group.equals("Admin")){
            Log.i("iduser",""+idUser)
            edtGender.isEnabled = true
            edtAsalNegara.isEnabled = true
            //user_camera_floating_button.visibility = View.GONE
            //btn_uploadKTP.visibility = View.INVISIBLE
            //btnSimpan.visibility = View.GONE
            //edtNama.isEnabled = false
            //edtKeperluan.isEnabled = false
            //edtPassword.isEnabled = false
            API.getUser(idUser)
                .enqueue(object : Callback<ArrayList<User>> {

                    override fun onResponse(
                        call: Call<ArrayList<User>>,
                        response: Response<ArrayList<User>>
                    ) {
                        if (response.code() == 200) {
                            val mUser: User = response.body()?.get(0)!!

                            if(mUser.nama.isNullOrEmpty()){
                                edtNama.setText("-")
                            }else{
                                edtNama.setText(mUser.nama)
                            }
                            edtUsername.setText(mUser.username)
                            edtPassword.setText(mUser.password)
                            if (mUser.keperluan.isNullOrEmpty()){
                                edtKeperluan.setText("-")

                            } else {
                                edtKeperluan.setText(mUser.keperluan)

                            }
                            edtEmail.setText(mUser.email)
                            edtGender.setText(mUser.jenisKelamin)
                            edtAsalNegara.setText(mUser.CountryOrigin)
                            edtNoHp.setText(mUser.noHp)
                            val foto = mUser.foto_diri
                            val fotoKtp = mUser.foto_ktp
                            var imgPath:String = "null"

                            if (foto != null && foto != "") {
                                imgPath = API.baseURLImage + mUser.foto_diri
                            }
                            else{
                                imgPath = baseURLImage + "FOTO_EMPTY.jpg"
                            }
                                Picasso.with(user_profile_photo.context)
                                    .load(imgPath)
                                    .into(user_profile_photo)
                            if(user_profile_photo.drawable == null){
                                imgPath = baseURLImage + "FOTO_EMPTY.jpg"
                                Picasso.with(user_profile_photo.context)
                                    .load(imgPath)
                                    .into(user_profile_photo)
                            }
                                var mFile = createImageFile()

                                fileUploads[0] = getBitmapFromURL(imgPath, mFile!!)

                                user_profile_photo_default.visibility = View.GONE
                                user_profile_photo.visibility = View.VISIBLE

                            if (fotoKtp != null && fotoKtp != "") {
                                imgPath = API.baseURLImage + mUser.foto_ktp
                            }
                            else{
                                imgPath = baseURLImage + "FOTO_EMPTY.jpg"
                            }
                                Picasso.with(vw_imgKtp.context)
                                    .load(imgPath)
                                    .into(vw_imgKtp)
                            if(vw_imgKtp.drawable == null){
                                imgPath = baseURLImage + "FOTO_EMPTY.jpg"
                                Picasso.with(vw_imgKtp.context)
                                    .load(imgPath)
                                    .into(vw_imgKtp)
                            }
                                mFile = createImageFile()
                                fileUploads[1] = getBitmapFromURL(imgPath, mFile!!)

                            progressDialog.dismiss()

                        } else {
                            Toast.makeText(
                                this@MenuUserActivity,
                                "Gagal memuat data",
                                Toast.LENGTH_SHORT
                            ).show()
                            progressDialog.dismiss()
                        }

                    }

                    override fun onFailure(call: Call<ArrayList<User>>, throwable: Throwable) {
                        Toast.makeText(
                            this@MenuUserActivity,
                            "Tidak tersambung dengan server. Periksa koneksi anda",
                            Toast.LENGTH_SHORT
                        ).show()
                        progressDialog.dismiss()

                    }
                })
        }
    }


    fun isValid(): Boolean {
        var valid: Boolean = true

        val nama = edtNama.text.toString()
        val keperluan = edtKeperluan.text.toString()
        val username = edtUsername.text.toString()
        val password = edtPassword.text.toString()
        val email = edtEmail.text.toString()
        val noHp = edtNoHp.text.toString()

        if (nama.isEmpty()) {
            edtNama.error = "Nama harus diisi"
            valid = false
        } else if (keperluan.isEmpty()) {
            edtKeperluan.error = "Keperluan kedatangan harus diisi"
            valid = false
        } else if (username.isEmpty()) {
            edtUsername.error = "Username harus diisi"
            valid = false
        } else if (password.isEmpty()) {
            edtPassword.error = "Password harus diisi"
            valid = false
        }
        else if (email.isEmpty()) {
            edtEmail.error = "Email harus diisi"
            valid = false
        }
        else if (noHp.isEmpty()) {
            edtNoHp.error = "No HP harus diisi"
            valid = false
        }


        return valid
    }

    fun saveData() {

        if (isValid()) {
            val progressDialog = ProgressDialog(this@MenuUserActivity)
            progressDialog.setMessage("Menyimpan data...")
            progressDialog.show()
            progressDialog.setCancelable(false)
            var savedUser:User = User()
            var id:String = ""
            if(idUser.equals("A")){
                savedUser = Gson().fromJson<User>(
                    this@MenuUserActivity.getSharedPreferences(
                        LoginActivity.MY_LOGIN_PREF,
                        Context.MODE_PRIVATE
                    ).getString(LoginActivity.MY_LOGIN_PREF_KEY, ""), User::class.java
                )
                id = savedUser.id!!
            }
            else{
                id = idUser
            }

            userModel.nama = edtNama.text.toString()
            userModel.username = edtUsername.text.toString()
            userModel.password = edtPassword.text.toString()
            userModel.keperluan = edtKeperluan.text.toString()
            userModel.id = id
            userModel.modiBy = id
            userModel.email = edtEmail.text.toString()
            userModel.noHp = edtNoHp.text.toString()

            val compileFileUploads = java.util.ArrayList<File>()
            fileUploads.forEach { if (it != null) compileFileUploads.add(it) }

            Log.i("test",""+compileFileUploads)
            Log.i("test",""+userModel.keperluan)

            API.updateMenuUser(userModel, compileFileUploads).enqueue(object : Callback<User> {

                override fun onResponse(
                    call: Call<User>,
                    response: Response<User>
                ) {
                    if (response.code() == 200) {
                        Toast.makeText(
                            this@MenuUserActivity,
                            "Sukses menyimpan data",
                            Toast.LENGTH_SHORT
                        ).show()
                        progressDialog.dismiss()

                        finish()
                    } else {
                        Toast.makeText(
                            this@MenuUserActivity,
                            "Gagal menyimpan data",
                            Toast.LENGTH_SHORT
                        ).show()
                        progressDialog.dismiss()

                    }

                }


                override fun onFailure(call: Call<User>, throwable: Throwable) {
                    Toast.makeText(
                        this@MenuUserActivity,
                        "Tidak tersambung dengan server. Periksa koneksi anda",
                        Toast.LENGTH_SHORT
                    ).show()
                    progressDialog.dismiss()

                }
            })

        }

    }

    @SuppressLint("NewApi")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK) return
        if(requestCode == REQUEST_KTP_CAPTURE){
            val temp = data?.getStringExtra("img_path");
            fileKTP = File(temp)
            dataUri = Uri.fromFile(fileKTP)
            val thumbnail = MediaStore.Images.Media.getBitmap(
                contentResolver, dataUri
            )
            fileUploads[1] = fileKTP
            //storeImageToUploadArray(fileKTP!!,"ktp")
            vw_imgKtp.setImageBitmap(thumbnail)
            return
        }

        data?.let {
            dataUri = it.data
            val thumbnail = MediaStore.Images.Media.getBitmap(
                contentResolver, dataUri
            )

            if (requestCode == GALLERY_KITKAT_INTENT_CALLED) {
                val takeFlags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                // Check for the freshest data.
                if (dataUri != null) {
                    this.contentResolver.takePersistableUriPermission(dataUri!!, takeFlags)
                }
            }
            fileUploads[0] = FileUtils.getFile(this@MenuUserActivity,dataUri)
            //storeImageToUploadArray(FileUtils.getFile(this@MenuUserActivity,dataUri),"diri")
            user_profile_photo_default.visibility = View.GONE
            user_profile_photo.visibility = View.VISIBLE
            user_profile_photo.setImageBitmap(thumbnail)

        }
    }

    private fun checkPermission() : Boolean {
        if(Build.VERSION.SDK_INT>=android.os.Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE)) {
                    val alertBuilder = android.app.AlertDialog.Builder(this)
                    alertBuilder.setCancelable(true)
                    alertBuilder.setTitle("Permission necessary")
                    alertBuilder.setMessage("Read access to storage is needed!")
                    alertBuilder.setPositiveButton(android.R.string.yes, DialogInterface.OnClickListener { dialog, which ->
                        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), MY_PERMISSIONS_REQUEST_EXTERNAL_STORAGE)
                    })
                    alertBuilder.create().show()
                } else {
                    ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), MY_PERMISSIONS_REQUEST_EXTERNAL_STORAGE)
                }
                return false
            } else {
                return true
            }
        } else {
            return true
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == MY_PERMISSIONS_REQUEST_EXTERNAL_STORAGE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getFileChooserIntent()
            }
        }
    }
    fun getBitmapFromURL(src: String?, file:File):File {
        var mBmp: Bitmap? = null;
        try {
            val is_ = URL(src).content as InputStream
            mBmp = BitmapFactory.decodeStream(is_)
        } catch (e: IOException) {
            e.printStackTrace()
            null
        }
        try {
            val fos = FileOutputStream(file)
            mBmp!!.compress(
                Bitmap.CompressFormat.JPEG,
                100,
                fos
            ) //compress existing dengan rewrite file
            fos.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return file
    }
    private fun getFileChooserIntent() {

        if (Build.VERSION.SDK_INT < 19) {
            val intent = Intent()
            intent.type = "/"
            intent.action = Intent.ACTION_GET_CONTENT
            startActivityForResult(Intent.createChooser(intent, "Select Picture"), GALLERY_INTENT_CALLED)
        } else {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
            intent.addCategory(Intent.CATEGORY_OPENABLE)
            intent.type = "*/*"
            startActivityForResult(intent, GALLERY_KITKAT_INTENT_CALLED)
        }
    }

    @Throws(IOException::class)
    private fun createImageFile(): File? {
        // Create an image file name
        val timeStamp =
            SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        val imageFileName = "JPEG_" + timeStamp + "_"
        val storageDir = Environment.getExternalStorageDirectory()
        return File.createTempFile(
            imageFileName,  /* prefix */
            ".jpg",  /* suffix */
            storageDir /* directory */
        )
    }
    inner class FileUpload(var bitmap: Bitmap, var fileName: String, var type: String, var fieldName: String?)

    fun setContext(context: Context) {
        val prefs = context.getSharedPreferences("X", Context.MODE_PRIVATE)
        val id = prefs.getString("idUser", "")
        if (id != null) {
            idUser = id
        }
    }

    companion object
}
