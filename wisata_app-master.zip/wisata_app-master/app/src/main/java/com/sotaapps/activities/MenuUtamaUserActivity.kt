package com.sotaapps.activities

import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.PopupMenu
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.gson.Gson
import com.sotaapps.R
import com.sotaapps.adapter.MenuUtamaUserAdapter
import com.sotaapps.connection.API
import com.sotaapps.model.User
import com.sotaapps.model.Wisata
import com.sotaapps.utils.RecyclerViewClickListener
import kotlinx.android.synthetic.main.activity_menu_utama_user.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class MenuUtamaUserActivity : AppCompatActivity(), RecyclerViewClickListener {

    private lateinit var linearLayoutManager: LinearLayoutManager
    var datas: ArrayList<Wisata>? = null
    var tempDatas: ArrayList<Wisata>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu_utama_user)

        val savedUser = Gson().fromJson<User>(
            this@MenuUtamaUserActivity.getSharedPreferences(
                LoginActivity.MY_LOGIN_PREF,
                Context.MODE_PRIVATE
            ).getString(LoginActivity.MY_LOGIN_PREF_KEY, ""), User::class.java
        )
        val id = savedUser.id
        API.getAntrianUser(id)
            .enqueue(object : Callback<ArrayList<User>> {

                override fun onResponse(
                    call: Call<ArrayList<User>>,
                    response: Response<ArrayList<User>>
                ) {
                    if (response.code() == 200) {
                        if(response.body()!!.size == 0 ){
                            val preferences = this@MenuUtamaUserActivity.getSharedPreferences(
                                LoginActivity.MY_LOGIN_PREF,
                                Context.MODE_PRIVATE
                            )
                            preferences!!.edit().remove(LoginActivity.MY_LOGIN_PREF_KEY).apply()
                            val i = Intent(this@MenuUtamaUserActivity, LoginActivity::class.java)
                            startActivity(i)
                            finish()
                        }
                        else{
                            txtNama.setText("Selamat datang, "+response.body()?.get(0)?.nama)
                            txtAntrian.setText("Nomor antrian : "+response.body()?.get(0)?.nomorAntrian)
                        }

                    } else {
                        Toast.makeText(
                            this@MenuUtamaUserActivity,
                            "Gagal memuat data",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                }

                override fun onFailure(call: Call<ArrayList<User>>, throwable: Throwable) {
                    Toast.makeText(
                        this@MenuUtamaUserActivity,
                        "Tidak tersambung dengan server. Periksa koneksi anda",
                        Toast.LENGTH_SHORT
                    ).show()

                }
            })



        linearLayoutManager = LinearLayoutManager(this)
        rvMenuUtama.layoutManager = linearLayoutManager

        ivPilihan.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View) {
                val popup = PopupMenu(this@MenuUtamaUserActivity, ivPilihan)
                popup.menuInflater.inflate(R.menu.main, popup.menu)
                popup.setOnMenuItemClickListener(object : PopupMenu.OnMenuItemClickListener {
                    override fun onMenuItemClick(item: MenuItem): Boolean {
                        if (item.itemId === R.id.action_logout) {
                            val preferences = this@MenuUtamaUserActivity.getSharedPreferences(
                                LoginActivity.MY_LOGIN_PREF,
                                Context.MODE_PRIVATE
                            )
                            preferences!!.edit().remove(LoginActivity.MY_LOGIN_PREF_KEY).apply()
                            val i = Intent(this@MenuUtamaUserActivity, LoginActivity::class.java)
                            startActivity(i)
                            finish()
                        } else if (item.itemId === R.id.action_menu_user) {
                            val i = Intent(this@MenuUtamaUserActivity, MenuUserActivity::class.java)
                            i.putExtra("mode", "A")
                            startActivity(i)
                        }
                        return false
                    }
                })
                popup.show()
            }
        })


        getData()

    }

    override fun onBackPressed() {
        val dialog = AlertDialog.Builder(this@MenuUtamaUserActivity)
        dialog.setTitle("Sota Apps")
            .setMessage("Apakah Anda ingin keluar dari aplikasi ini?")
            .setPositiveButton("Ya") { dialog, which ->
                super.onBackPressed()
                finish()
            }
            .setNegativeButton("Tidak", { paramDialogInterface, paramInt -> })
        dialog.show()
    }

    fun getData() {
        val progressDialog = ProgressDialog(this@MenuUtamaUserActivity)
        progressDialog.setMessage("Memuat data...")
        progressDialog.show()
        progressDialog.setCancelable(false)
        API.getAllWisata()
            .enqueue(object : Callback<ArrayList<Wisata>> {

                override fun onResponse(
                    call: Call<ArrayList<Wisata>>,
                    response: Response<ArrayList<Wisata>>
                ) {
                    if (response.code() == 200) {
                        datas = response.body()
                        tempDatas = datas

                        if (tempDatas!!.isEmpty()) {

                            tvTidakAdaData.visibility = View.VISIBLE
                            rvMenuUtama.visibility = View.GONE
                            progressDialog.dismiss()

                        } else {

                            rvMenuUtama!!.setHasFixedSize(true)
                            rvMenuUtama!!.layoutManager =
                                LinearLayoutManager(this@MenuUtamaUserActivity)

                            val adapter = MenuUtamaUserAdapter(tempDatas!!)
                            rvMenuUtama!!.adapter = adapter

                            adapter.listener = this@MenuUtamaUserActivity

                            progressDialog.dismiss()
                        }
                    } else {
                        Toast.makeText(
                            this@MenuUtamaUserActivity,
                            "Gagal memuat data",
                            Toast.LENGTH_SHORT
                        ).show()
                        progressDialog.dismiss()
                    }

                }

                override fun onFailure(call: Call<ArrayList<Wisata>>, throwable: Throwable) {
                    Toast.makeText(
                        this@MenuUtamaUserActivity,
                        "Tidak tersambung dengan server. Periksa koneksi anda",
                        Toast.LENGTH_SHORT
                    ).show()
                    progressDialog.dismiss()

                }
            })

    }


    override fun onItemClicked(view: View, wisata: Wisata) {

        val i = Intent(this@MenuUtamaUserActivity, DetailWisataActivity::class.java)
        val id_wisata = wisata.id
        i.putExtra("ID_WISATA", id_wisata)
        startActivity(i)
    }

    companion object


}