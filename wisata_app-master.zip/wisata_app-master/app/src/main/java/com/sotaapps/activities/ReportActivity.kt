package com.sotaapps.activities

import android.Manifest
import android.app.DatePickerDialog
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.sotaapps.R
import com.sotaapps.connection.API
import com.sotaapps.model.User
import kotlinx.android.synthetic.main.activity_report.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.text.SimpleDateFormat
import java.util.*

class ReportActivity : AppCompatActivity() {
    internal var valueBulan : String? = null
    internal var valueTahun : String? = null
    internal var valueTipeReport : String? = null
    val myCalendar = Calendar.getInstance()
    private val MY_PERMISSION_REQUEST_WRITE_STORAGE = 100
    val excelStuff = ReportExcel(this@ReportActivity)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_report)

        val tipe_spinner = arrayOf("-- Pilih Jenis Report --", "Perhari", "Perbulan")
        val id_tipe = arrayOf<String>("0","Perhari", "Perbulan")

        val adapterTipe = ArrayAdapter(this@ReportActivity, android.R.layout.simple_spinner_dropdown_item, tipe_spinner)
        jenis_report.adapter = adapterTipe

        jenis_report.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                valueTipeReport = id_tipe.get(position)

                if(valueTipeReport.equals("Perhari")) {
                    tanggal.visibility = View.VISIBLE
                    btn_calendar.visibility = View.VISIBLE

                    txt_bulan.visibility = View.GONE
                    spn_bulan.visibility = View.GONE
                    txt_tahun.visibility = View.GONE
                    spn_tahun.visibility = View.GONE

                    val date = DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->
                        myCalendar.set(Calendar.YEAR, year)
                        myCalendar.set(Calendar.MONTH, monthOfYear)
                        myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                        updateLabel()
                    }


                    btn_calendar.setOnClickListener {
                        DatePickerDialog(this@ReportActivity, date, Calendar.getInstance()
                            .get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH),
                            Calendar.getInstance().get(Calendar.DAY_OF_MONTH)).show()
                    }
                }else if(valueTipeReport.equals("Perbulan")){
                    txt_bulan.visibility = View.VISIBLE
                    spn_bulan.visibility = View.VISIBLE
                    txt_tahun.visibility = View.VISIBLE
                    spn_tahun.visibility = View.VISIBLE

                    tanggal.visibility = View.GONE
                    btn_calendar.visibility = View.GONE

                    val bulan = arrayOf("-- Pilih Bulan -- ", "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember")
                    val id_bulan = arrayOf<String>("0","01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12")
                    val adapterBulan = ArrayAdapter(this@ReportActivity, android.R.layout.simple_spinner_dropdown_item, bulan)
                    spn_bulan.adapter = adapterBulan

                    spn_bulan.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                        override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                            valueBulan = id_bulan.get(position)
                        }
                        override fun onNothingSelected(parent: AdapterView<*>) {

                        }
                    }

                    val tahun = arrayOf("-- Pilih Tahun -- ", "2020", "2021", "2022", "2023", "2024", "2025")
                    val adapterTahun = ArrayAdapter(this@ReportActivity, android.R.layout.simple_spinner_dropdown_item, tahun)
                    spn_tahun.adapter = adapterTahun

                    spn_tahun.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                        override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                            valueTahun = tahun.get(position)
                        }
                        override fun onNothingSelected(parent: AdapterView<*>) {

                        }
                    }
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>) {

            }
        }

        btnReport.setOnClickListener {
            getData()
        }
    }

    private fun updateLabel() {
        val myFormat = "dd-MM-yyyy"
        val sdf = SimpleDateFormat(myFormat, Locale.US)

        val myFormat2 = "yyyy-MM-dd"
        val sdf2 = SimpleDateFormat(myFormat2, Locale.US)
        valueBulan = sdf2.format(myCalendar.time)

        tanggal.setText(sdf.format(myCalendar.time))
    }


    fun isValid() : Boolean {
        var valid : Boolean = true

        if(valueTipeReport == null || valueTipeReport.equals("0")){
            Toast.makeText(this@ReportActivity, "Anda harus memilih jenis report!", Toast.LENGTH_LONG).show()
            valid = false
        }else if(valueTipeReport.equals("Perhari")){
            if(valueBulan == null || valueBulan.equals("0")){
                Toast.makeText(this@ReportActivity, "Tanggal tidak boleh kosong!", Toast.LENGTH_LONG).show()
                valid = false
            }
        }else if(valueTipeReport.equals("Perbulan")){
            if(valueBulan == null || valueBulan.equals("0")){
                Toast.makeText(this@ReportActivity, "Anda belum mengisi bulan!", Toast.LENGTH_LONG).show()
                valid = false
            }
        }else if(valueTahun.equals("-- Pilih Tahun --")){
            Toast.makeText(this@ReportActivity, "Anda belum mengisi Tahun!", Toast.LENGTH_LONG).show()
            valid = false
        }
        return valid
    }

    fun getData(){
        if (isValid()){
            if (ContextCompat.checkSelfPermission(this@ReportActivity,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this@ReportActivity,
                    arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA),
                    MY_PERMISSION_REQUEST_WRITE_STORAGE)
            } else {
                if(valueTipeReport.equals("Perbulan")){
                    valueBulan = valueTahun+"-"+valueBulan
                    excelStuff.createReport(valueTipeReport, valueBulan)
                }else{
                    excelStuff.createReport(valueTipeReport, valueBulan)
                }
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}