package com.sotaapps.activities

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.util.Log
import android.widget.Toast
import androidx.core.content.FileProvider
import com.sotaapps.connection.API
import com.sotaapps.model.User
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import java.util.*
import kotlin.collections.ArrayList
import jxl.Workbook
import jxl.WorkbookSettings
import jxl.format.Colour
import jxl.format.UnderlineStyle
import jxl.write.Label
import jxl.write.WritableCellFormat
import jxl.write.WritableFont
import jxl.write.WritableWorkbook

class ReportExcel(private val context: Context) {
    var datas: java.util.ArrayList<User>? = null

    fun createReport(periode: String?, date: String?) {
        API.getReport(periode, date).enqueue(object : Callback<ArrayList<User>> {
            override fun onResponse(call: Call<ArrayList<User>>, response: Response<ArrayList<User>>) {
                if (response.code() == 200) {

                    datas = response.body()

                    if (datas?.size != 0) {
                        val sd = Environment.getExternalStorageDirectory()

                        val csvFile = "Report_ $date _.xls"

                        val directory = File(sd.absolutePath)
                        //create directory if not exist
                        if (!directory.isDirectory) {
                            directory.mkdirs()
                        }
                        try {

                            //file path
                            val file = File(directory, csvFile)
                            val wbSettings = WorkbookSettings()
                            wbSettings.locale = Locale("en", "EN")
                            val workbook: WritableWorkbook
                            workbook = Workbook.createWorkbook(file, wbSettings)
                            //Excel sheet name. 0 represents first sheet
                            val sheet = workbook.createSheet("userList", 0)

                            val titleReport = WritableFont(WritableFont.ARIAL, 16, WritableFont.BOLD, false, UnderlineStyle.NO_UNDERLINE)
                            val titleFormat = WritableCellFormat(titleReport)
                            sheet.addCell(Label(0, 0, "Report", titleFormat))

                            val header = WritableFont(WritableFont.ARIAL, 10, WritableFont.BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.WHITE)
                            val headerFormat = WritableCellFormat(header)
                            headerFormat.setBackground(Colour.DARK_BLUE)
                            sheet.addCell(Label(0, 5, "No", headerFormat))
                            sheet.addCell(Label(1, 5, "Nama Pengunjung", headerFormat)) // column and row
                            sheet.addCell(Label(2, 5, "Username", headerFormat))
                            sheet.addCell(Label(3, 5, "Alamat", headerFormat))
                            sheet.addCell(Label(4, 5, "Email", headerFormat))
                            sheet.addCell(Label(5, 5, "No Telepon", headerFormat))
                            sheet.addCell(Label(6, 5, "Jenis Kelamin", headerFormat))
                            sheet.addCell(Label(7, 5, "Keperluan Kedatangan", headerFormat))

                            datas?.forEachIndexed { i, element ->

                                val pos = i + 6
                                val number = i + 1
                                val numbs = number.toString()

                                val nama = element.nama
                                val username = element.username
                                val alamat = element.alamat
                                val email = element.email
                                val nohp = element.noHp
                                var jk = element.jenisKelamin
                                var keperluan = element.keperluan

                                if (jk.equals("W")) {
                                    jk = "Wanita"
                                } else {
                                    jk = "Laki-Laki"
                                }

                                sheet.addCell(Label(0, pos, numbs))
                                sheet.setColumnView(0, 5)

                                sheet.addCell(Label(1, pos, nama))
                                sheet.setColumnView(1, 20)

                                sheet.addCell(Label(2, pos, username))
                                sheet.setColumnView(2, 20)

                                sheet.addCell(Label(3, pos, alamat))
                                sheet.setColumnView(3, 20)

                                sheet.addCell(Label(4, pos, email))
                                sheet.setColumnView(4, 20)

                                sheet.addCell(Label(5, pos, nohp))
                                sheet.setColumnView(5, 20)

                                sheet.addCell(Label(6, pos, jk))
                                sheet.setColumnView(6, 20)

                                sheet.addCell(Label(7, pos, keperluan))
                                sheet.setColumnView(6, 20)
                            }

                            //closing cursor
                            var success: Boolean? = false
                            val fullPath = Environment.getExternalStorageDirectory().absolutePath + "/" + csvFile

                            val dir = File(fullPath)
                            try {
                                workbook.write()
                                workbook.close()
                                success = true
                            } catch (e: Exception) {
                                Log.e("saveToExternalStorage()", e.message!!)
                            }

                            if (success!!) {
                                val intent = Intent(Intent.ACTION_VIEW)
                                if (Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                                    intent.flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
                                    val fileUri = FileProvider.getUriForFile(context, context.applicationContext.packageName + ".provider", dir)
                                    intent.setDataAndType(fileUri, "application/vnd.ms-excel")
                                } else {
                                    intent.setDataAndType(Uri.fromFile(dir), "application/vnd.ms-excel")
                                }

                                try {
                                    context.startActivity(intent)
                                } catch (ex: Exception) {
                                    ex.printStackTrace()
                                    Toast.makeText(context, "You need to have Microsoft Office Excel Installed here", Toast.LENGTH_LONG).show()
                                } finally {
                                    Toast.makeText(context, "Success create report on " + dir.path, Toast.LENGTH_LONG).show()
                                }
                            }

                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    } else {
                        Toast.makeText(context, "Data Tidak Ada", Toast.LENGTH_LONG).show()
                    }
                } else {
                    Toast.makeText(context, "Error", Toast.LENGTH_LONG).show()
                }
            }

            override fun onFailure(call: Call<ArrayList<User>>, throwable: Throwable) {
                Toast.makeText(context, "Please check your connection", Toast.LENGTH_LONG).show()
            }
        })

    }

}