package com.sotaapps.activities

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.sotaapps.R
import com.sotaapps.connection.API
import com.sotaapps.model.User
import kotlinx.android.synthetic.main.activity_signup.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File


class SignupActivity : AppCompatActivity() {
    private val REQUEST_IMAGE_CAPTURE = 100;
    val REQUEST_KTP_CAPTURE = 102;
    var fileFace:File? = null
    var fileKTP:File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        getSupportActionBar()!!.hide()

        tv_login.setOnClickListener {
            startActivity(Intent(this@SignupActivity, LoginActivity::class.java))
            finish()
        }
        btn_goCapture.setOnClickListener(){
            val mI:Intent = Intent(this@SignupActivity, activity_goCapture::class.java)
            mI.putExtra("mode",REQUEST_KTP_CAPTURE)
            startActivityForResult(Intent(this@SignupActivity, activity_goCapture::class.java), REQUEST_KTP_CAPTURE)
        }
        btn_goCaptureDiri.setOnClickListener(){
            val mI:Intent = Intent(this@SignupActivity, activity_goCapture::class.java)
            mI.putExtra("mode",REQUEST_IMAGE_CAPTURE)
            startActivityForResult(mI, REQUEST_IMAGE_CAPTURE)
        }

        progressBar.visibility = View.INVISIBLE
        getJenisKelamin()
        setNegaraList()

        btnSignup.setOnClickListener(){
            doRegister()
        }
    }

    fun getJenisKelamin() {
        val items: Array<String?> = arrayOf(null, "Pria", "Wanita")
        val adapter = CustomAdapter<String?>(this, R.layout.spinner_custom, R.layout.spinner_dropdown_item, items)
        spn_jenis_kelamin.adapter = adapter
    }
    fun setNegaraList() {
        val items: Array<String?> = arrayOf(null, "Azerbaijan", "Bangladesh", "Chile", "Deutsch", "England", "Findland", "Hungary", "Indonesia",
            "Japan", "Kongo", "Laos", "Malaysia", "Nepal", "Oman", "Peru", "Qatar", "Russia", "Thailand", "Ukraine", "Venezuela", "Yemen", "Zimbabwe")
        val adapter = CustomAdapter<String?>(this, R.layout.spinner_custom, R.layout.spinner_dropdown_item, items)
        spn_negara.adapter = adapter
    }

    fun isValid(): Boolean{
        var valid: Boolean = true
        val nama = edt_nama.text.toString()
        val username = edt_username.text.toString()
        val password = edt_password.text.toString()
        val alamat = edt_alamat.text.toString()
        val email = edt_email.text.toString()
        val noHp = edt_no_hp.text.toString()
        val jenisKelamin = spn_jenis_kelamin.selectedItem
        val negara_asal = spn_negara.selectedItem
        val keperluanK = edt_keperluan.text.toString()

        if (nama.isEmpty()) {
            edt_nama.error = "Nama belum diisi"
            valid = false
        } else {
            edt_nama.error = null
        }

        if (username.isEmpty()) {
            edt_username.error = "Username belum diisi"
            valid = false
        } else {
            edt_username.error = null
            if (username.length < 3) {
                edt_username.setError("Username minimal 3 karakter")
                valid = false
            }
        }

        if (password.isEmpty()) {
            edt_password.error = "Password belum diisi"
            valid = false
        } else {
            edt_password.error = null
            if (password.length < 3) {
                edt_password.setError("Password minimal 3 karakter")
                valid = false
            }
        }

        if(fileFace == null){
            valid = false;
            Toast.makeText(applicationContext,"Belum mengambil foto diri",Toast.LENGTH_LONG).show();
        }

        if(fileKTP == null){
            valid = false;
            Toast.makeText(applicationContext,"Belum mengambil foto KTP",Toast.LENGTH_LONG).show();
        }

        if (alamat.isEmpty()) {
            edt_alamat.error = "Alamat belum diisi"
            valid = false
        } else {
            edt_alamat.error = null
        }

        if (keperluanK.isEmpty()) {
            edt_keperluan.error = "Keperluan Kedatangan belum diisi"
            valid = false
        } else {
            edt_keperluan.error = null
        }

        if (email.isEmpty()) {
            edt_email.error = "Email belum diisi"
            valid = false
        } else {
            edt_email.error = null
        }

        if (noHp.isEmpty()) {
            edt_no_hp.error = "No Hp belum diisi"
            valid = false
        } else {
            edt_no_hp.error = null
        }

        if (jenisKelamin == null) {
            Toast.makeText(this, "Jenis Kelamin harus dipilih", Toast.LENGTH_SHORT).show()
            valid = false
        }

        if (negara_asal == null) {
            Toast.makeText(this, "Asal negara harus dipilih", Toast.LENGTH_SHORT).show()
            valid = false
        }

        if (email.isNotEmpty()) {
            if (!isValidEmail(email)) {
                edt_email.error = "Format email salah"
                valid = false
            }
        }

        return valid
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == activity_goCapture.REQUEST_IMAGE_CAPTURE && resultCode == Activity.RESULT_OK) {
            val temp = data?.getStringExtra("img_path");
            fileFace = File(temp)
            btn_goCaptureDiri.visibility = View.INVISIBLE
            txt_detailGoCaptureDiri.text = "Foto Diri OK !"
        }
        if (requestCode == activity_goCapture.REQUEST_KTP_CAPTURE && resultCode == Activity.RESULT_OK) {
            val temp = data?.getStringExtra("img_path");
            fileKTP = File(temp)
            btn_goCapture.visibility = View.INVISIBLE
            txt_detailGoCapture.text = "Foto KTP OK !"
        }
    }

    private fun isValidEmail(email: String): Boolean {
        return !TextUtils.isEmpty(email) && android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    fun doRegister(){

        if (!isValid()) {
            btnSignup.visibility = View.VISIBLE
            progressBar.visibility=View.INVISIBLE
            return
        }

        val dataUser = User()
        dataUser.nama = edt_nama.text.toString()
        dataUser.username = edt_username.text.toString()
        dataUser.password = edt_password.text.toString()
        dataUser.alamat = edt_alamat.text.toString()
        dataUser.email = edt_email.text.toString()
        dataUser.noHp = edt_no_hp.text.toString()
        dataUser.jenisKelamin = spn_jenis_kelamin.selectedItem.toString()
        dataUser.CountryOrigin = spn_negara.selectedItem.toString()
        dataUser.keperluan = edt_keperluan.text.toString()
        btnSignup.visibility = View.INVISIBLE
        progressBar.visibility=View.VISIBLE
        API.validasiUsername(edt_username.text.toString())
            .enqueue(object : Callback<ArrayList<User>> {

                override fun onResponse(
                    call: Call<ArrayList<User>>,
                    response: Response<ArrayList<User>>
                ) {
                    if (response.code() == 200) {

                        if (response.body()!!.isEmpty()) {
                            API.doRegister(dataUser, fileFace, fileKTP).enqueue(object : Callback<User> {
                                override fun onResponse(call: Call<User>, response: Response<User>) {
                                    if (response.code() == 200){
                                        Toast.makeText(this@SignupActivity, "Sukses", Toast.LENGTH_SHORT).show()
                                        startActivity(Intent(this@SignupActivity, LoginActivity::class.java))
                                        finish()
                                    } else {
                                        Toast.makeText(this@SignupActivity, "Gagal registrasi", Toast.LENGTH_SHORT).show()
                                        btnSignup.visibility = View.VISIBLE
                                        progressBar.visibility = View.INVISIBLE
                                    }

                                }

                                override fun onFailure(call: Call<User>, t: Throwable) {
                                    Toast.makeText(this@SignupActivity, "Gagal registrasi", Toast.LENGTH_SHORT).show()
                                    btnSignup.visibility = View.VISIBLE
                                    progressBar.visibility = View.GONE
                                }
                            })
                        } else {
                            val builder = android.app.AlertDialog.Builder(this@SignupActivity)
                            builder.setMessage("Username " + edt_username.text.toString() + " sudah ada. Mohon ganti dengan username yang lain")
                                .setPositiveButton("ganti") { dialog, which ->
                                    dialog.dismiss()
                                }
                            builder.show()

                        }


                    } else {
                        Toast.makeText(this@SignupActivity, "Gagal validasi username", Toast.LENGTH_SHORT).show()
                        btnSignup.visibility = View.VISIBLE
                        progressBar.visibility = View.GONE
                    }

                }

                override fun onFailure(call: Call<ArrayList<User>>, throwable: Throwable) {
                    Toast.makeText(this@SignupActivity, "Tidak tersambung dengan server. Periksa koneksi anda", Toast.LENGTH_SHORT).show()

                    btnSignup.visibility = View.VISIBLE
                    progressBar.visibility = View.GONE

                }
            })
    }



    class CustomAdapter<T>(context: Activity, val viewResourceId: Int, val dropDownReourceId: Int, val list: Array<T>) : ArrayAdapter<T>(context, viewResourceId, dropDownReourceId, list) {

        internal var layoutInflater: LayoutInflater = context.layoutInflater

        override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup?): View {
            return getCustomView(position, convertView, parent, dropDownReourceId)
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            return getCustomView(position, convertView, parent, viewResourceId)
        }


        fun getCustomView(position: Int, convertView: View?, parent: ViewGroup?, resourceId: Int): View {

            var view = convertView

            if (view == null) {
                view = layoutInflater.inflate(resourceId, parent, false)
            }

            val textView = view as? TextView
            if (list[position] != null) {
                textView?.text = list[position].toString()
            } else {
                textView?.text = "Pilih"
            }

            return view!!
        }


    }

}