package com.sotaapps.activities

import android.app.Activity
import android.app.ProgressDialog
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import com.sotaapps.R
import com.sotaapps.connection.API
import com.sotaapps.model.User
import kotlinx.android.synthetic.main.activity_menu_user.btnSimpan
import kotlinx.android.synthetic.main.activity_menu_user.edtKeperluan
import kotlinx.android.synthetic.main.activity_menu_user.edtNama
import kotlinx.android.synthetic.main.activity_menu_user.edtPassword
import kotlinx.android.synthetic.main.activity_menu_user.edtUsername
import kotlinx.android.synthetic.main.activity_tambah_pengunjung.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class TambahDataPengunjungActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tambah_pengunjung)

        getJenisKelamin()

        btnSimpan.setOnClickListener {
            addData()
        }

    }

    fun getJenisKelamin() {
        val items: Array<String?> = arrayOf(null, "Pria", "Wanita")
        val adapter = CustomAdapter<String?>(
            this@TambahDataPengunjungActivity,
            R.layout.spinner_custom,
            R.layout.spinner_dropdown_item,
            items
        )
        spnJenisKelamin.adapter = adapter
        spnJenisKelamin.adapter = adapter
    }

    class CustomAdapter<T>(
        context: Activity,
        val viewResourceId: Int,
        val dropDownReourceId: Int,
        val list: Array<T>
    ) : ArrayAdapter<T>(context, viewResourceId, dropDownReourceId, list) {

        internal var layoutInflater: LayoutInflater = context.layoutInflater

        override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup?): View {
            return getCustomView(position, convertView, parent, dropDownReourceId)
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            return getCustomView(position, convertView, parent, viewResourceId)
        }


        fun getCustomView(
            position: Int,
            convertView: View?,
            parent: ViewGroup?,
            resourceId: Int
        ): View {

            var view = convertView

            if (view == null) {
                view = layoutInflater.inflate(resourceId, parent, false)
            }

            val textView = view as? TextView
            if (list[position] != null) {
                textView?.text = list[position].toString()
            } else {
                textView?.text = "Pilih"
            }

            return view!!
        }

    }

    fun isValid(): Boolean {
        var valid: Boolean = true

        val nama = edtNama.text.toString()
        val nohp = edtNomorHp.text.toString()
        val alamat = edtAlamat.text.toString()
        val jenisKelamin = spnJenisKelamin.selectedItemPosition.toString()
        val email = edtEmail.text.toString()
        val keperluan = edtKeperluan.text.toString()
        val username = edtUsername.text.toString()
        val password = edtPassword.text.toString()

        if (nama.isEmpty()) {
            edtNama.error = "Nama harus diisi"
            valid = false
        } else if (nohp.isEmpty()) {
            edtNomorHp.error = "Nomor handphone harus diisi"
            valid = false
        } else if (alamat.isEmpty()) {
            edtAlamat.error = "Alamat harus diisi"
            valid = false
        } else if (jenisKelamin.equals("0")) {
            Toast.makeText(
                this@TambahDataPengunjungActivity,
                "Jenis kelamin harus dipilih",
                Toast.LENGTH_SHORT
            ).show()
            valid = false
        } else if (email.isEmpty()) {
            edtEmail.error = "Email harus diisi"
            valid = false
        } else if (keperluan.isEmpty()) {
            edtKeperluan.error = "Keperluan kedatangan harus diisi"
            valid = false
        } else if (username.isEmpty()) {
            edtUsername.error = "Username harus diisi"
            valid = false
        } else if (password.isEmpty()) {
            edtPassword.error = "Password harus diisi"
            valid = false
        }

        return valid
    }


    fun addData() {

        if (isValid()) {

            val progressDialog = ProgressDialog(this@TambahDataPengunjungActivity)
            progressDialog.setMessage("Menambah data...")
            progressDialog.show()
            progressDialog.setCancelable(false)

            val savedUser = Gson().fromJson<User>(
                this@TambahDataPengunjungActivity.getSharedPreferences(
                    LoginActivity.MY_LOGIN_PREF,
                    Context.MODE_PRIVATE
                ).getString(LoginActivity.MY_LOGIN_PREF_KEY, ""), User::class.java
            )
            val id = savedUser.id
            val userModel = User()

            userModel.nama = edtNama.text.toString()
            userModel.username = edtUsername.text.toString()
            userModel.password = edtPassword.text.toString()
            userModel.keperluan = edtKeperluan.text.toString()
            userModel.email = edtEmail.text.toString()
            userModel.alamat = edtAlamat.text.toString()
            userModel.noHp = edtNomorHp.text.toString()
            userModel.jenisKelamin = spnJenisKelamin.selectedItem.toString()
            userModel.createdBy = id
            userModel.modiBy = id

            API.validasiUsername(edtUsername.text.toString())
                .enqueue(object : Callback<ArrayList<User>> {

                    override fun onResponse(
                        call: Call<ArrayList<User>>,
                        response: Response<ArrayList<User>>
                    ) {
                        if (response.code() == 200) {

                            if (response.body()!!.isEmpty()) {
                                API.addDataPengunjung(userModel).enqueue(object : Callback<User> {

                                    override fun onResponse(
                                        call: Call<User>,
                                        response: Response<User>
                                    ) {
                                        if (response.code() == 200) {
                                            Toast.makeText(
                                                this@TambahDataPengunjungActivity,
                                                "Sukses tambah data",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                            progressDialog.dismiss()

                                            finish()
                                        } else {
                                            Toast.makeText(
                                                this@TambahDataPengunjungActivity,
                                                "Gagal tambah data",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                            progressDialog.dismiss()

                                        }

                                    }


                                    override fun onFailure(call: Call<User>, throwable: Throwable) {
                                        Toast.makeText(
                                            this@TambahDataPengunjungActivity,
                                            "Tidak tersambung dengan server. Periksa koneksi anda",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                        progressDialog.dismiss()

                                    }
                                })
                            } else {

                                progressDialog.dismiss()
                                val builder =
                                    android.app.AlertDialog.Builder(this@TambahDataPengunjungActivity)
                                builder.setMessage("Username " + edtUsername.text.toString() + " sudah ada. Mohon ganti dengan username yang lain")
                                    .setPositiveButton("ganti") { dialog, which ->
                                        dialog.dismiss()
                                    }
                                builder.show()

                            }


                        } else {
                            Toast.makeText(
                                this@TambahDataPengunjungActivity,
                                "Gagal validasi username",
                                Toast.LENGTH_SHORT
                            ).show()
                            progressDialog.dismiss()
                        }

                    }

                    override fun onFailure(call: Call<ArrayList<User>>, throwable: Throwable) {
                        Toast.makeText(
                            this@TambahDataPengunjungActivity,
                            "Tidak tersambung dengan server. Periksa koneksi anda",
                            Toast.LENGTH_SHORT
                        ).show()
                        progressDialog.dismiss()

                    }
                })
        }
    }

    companion object
}