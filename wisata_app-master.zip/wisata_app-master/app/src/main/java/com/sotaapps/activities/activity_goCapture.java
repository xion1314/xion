package com.sotaapps.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.common.util.concurrent.ListenableFuture;
import com.sotaapps.R;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;

import static android.graphics.BitmapFactory.decodeStream;

public class activity_goCapture extends AppCompatActivity {
    static final int REQUEST_IMAGE_CAPTURE = 100, REQUEST_CODE_PERMISSIONS = 101, REQUEST_KTP_CAPTURE = 102;
    private final String[] REQUIRED_PERMISSIONS = new String[]
            {"android.permission.CAMERA", "android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE"};
    private File photoFile;
    private String filePath;
    private Intent takePictureIntent;
    private static int mMode;
    ImageCapture mImageCap;
    PreviewView previewView;
    Camera camera;
    CameraSelector cameraSelector;
    ImageButton btn_goCamera;
    Preview preview;
    int mode;

    private ListenableFuture<ProcessCameraProvider> cameraProviderFuture;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_go_capture);

        btn_goCamera = findViewById(R.id.btn_goCamera);
        previewView = findViewById(R.id.vw_previewCamera);

        Intent i = getIntent();
        mode = i.getIntExtra("mode",0);

        photoFile = null;
        filePath = null;
        takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        cameraProviderFuture = ProcessCameraProvider.getInstance(this);

        mMode = getIntent().getIntExtra("mode",0);

        if(allPermissionsGranted()){
            doTask(mMode);
        } else{
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS);
        }
    }

    private void doTask(int job){
        cameraProviderFuture.addListener(() -> {
            try {
                ProcessCameraProvider cameraProvider = cameraProviderFuture.get();
                bindPreview(cameraProvider);

            } catch (ExecutionException | InterruptedException e) {
                // No errors need to be handled for this Future.
                // This should never be reached.
            }
        }, ContextCompat.getMainExecutor(this));

        btn_goCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                filePath = Environment.getExternalStorageDirectory() + "/" + System.currentTimeMillis() + ".jpg";
                File file = new File(filePath);
                ImageCapture.OutputFileOptions outputFileOptions =
                        new ImageCapture.OutputFileOptions.Builder(file).build();

                mImageCap.takePicture(outputFileOptions, Executors.newCachedThreadPool(),
                        new ImageCapture.OnImageSavedCallback() {
                            @Override
                            public void onImageSaved(@NonNull ImageCapture.OutputFileResults outputFileResults) {
                                Intent imagePath = new Intent();
                                imagePath.putExtra("img_path",filePath);
                                setResult(Activity.RESULT_OK,imagePath);
                                finish();
                            }
                            @Override
                            public void onError(@NonNull ImageCaptureException exception) {
                            }
                        });
            }
        });
        try {
            photoFile = createImageFile();
        } catch (IOException ex) {

        }
        // Continue only if the File was successfully created
        if (photoFile != null) {
            //File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);

            //File output = new File(dir, "CameraContentDemo.jpeg");

            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(photoFile));
            if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
        //        startActivityForResult(takePictureIntent, job);
            }
        }

    }
    void bindPreview(@NonNull ProcessCameraProvider cameraProvider) {
        preview = new Preview.Builder()
                .build();

        mImageCap = new ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build();

        if (mode == REQUEST_IMAGE_CAPTURE) {//mode 1 adalah untuk mode fatektp//mode 3 adalah untuk mode face saja
            cameraSelector = new CameraSelector.Builder()
                    .requireLensFacing(CameraSelector.LENS_FACING_FRONT)
                    .build();
        } else {
            cameraSelector = new CameraSelector.Builder()
                    .requireLensFacing(CameraSelector.LENS_FACING_BACK)
                    .build();
        }


        cameraProvider.unbindAll();
        camera = cameraProvider.bindToLifecycle(this,cameraSelector,preview,mImageCap);
        preview.setSurfaceProvider(previewView.createSurfaceProvider(camera.getCameraInfo()));
    }

        @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        Toast.makeText(activity_goCapture.this, "FAIL ! " + Integer.toString(resultCode), Toast.LENGTH_LONG).show();

        if (resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            if (requestCode == REQUEST_IMAGE_CAPTURE) {
                Bitmap imageBitmap = rotateImage((Bitmap) extras.get("data"), 1f);
                compressImage(photoFile, imageBitmap);
            } else {
                Bitmap imageBitmap = rotateImage((Bitmap) extras.get("data"), 1f);
                compressImage(photoFile, imageBitmap);
            }
            filePath = photoFile.getPath();
            Intent imagePath = new Intent();
            imagePath.putExtra("img_path", filePath);
            setResult(Activity.RESULT_OK, imagePath);
            finish();
        }

    }

    private static Bitmap rotateImage(Bitmap img, float degree)
    {
        Matrix matrix = new Matrix();
        matrix.postRotate(degree);
        Bitmap rotatedImg = Bitmap.createBitmap(img, 0, 0, img.getWidth(), img.getHeight(), matrix, true);
        img.recycle();
        return rotatedImg;
    }


    private void compressImage(File imageFile, Bitmap bmp) {
        try {
            FileOutputStream fos = new FileOutputStream(imageFile);
            bmp.compress(Bitmap.CompressFormat.JPEG, 90, fos); //compress existing dengan rewrite file
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        if(requestCode == REQUEST_CODE_PERMISSIONS){
            if(allPermissionsGranted()){
                doTask(REQUEST_IMAGE_CAPTURE);
            } else{
                Toast.makeText(this, "Permohonan akses perangkat ditolak.", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }
    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = Environment.getExternalStorageDirectory();
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        return image;
    }

    private boolean allPermissionsGranted(){

        for(String permission : REQUIRED_PERMISSIONS){
            if(ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED){
                return false;
            }
        }
        return true;
    }

}