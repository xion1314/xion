package com.sotaapps.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.sotaapps.R;
import com.sotaapps.adapter.userListAdapter;
import com.sotaapps.connection.API;
import com.sotaapps.model.User;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class activity_userlist extends AppCompatActivity {
    ArrayList<User> mUserList;
    private RecyclerView userListView;
    private userListAdapter userListAdapter;
    private ProgressBar mProgress;
    private LinearLayout ctn_user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userlist);

        userListView = findViewById(R.id.vw_listUser);
        mProgress = findViewById(R.id.prog_user);
        ctn_user = findViewById(R.id.ctn_user);

        mUserList = new ArrayList<>();
        ctn_user.setVisibility(View.INVISIBLE);
        mProgress.setVisibility(View.VISIBLE);
        userListView.setLayoutManager(new LinearLayoutManager(this));
        userListAdapter = new userListAdapter();

        userListView.setAdapter(userListAdapter);

        API.INSTANCE.getAllUserInfo().enqueue(new Callback<ArrayList<User>>() {
            @Override
            public void onResponse(Call<ArrayList<User>> call, Response<ArrayList<User>> response) {
                if(response.code() == 200){
                    ctn_user.setVisibility(View.VISIBLE);
                    mProgress.setVisibility(View.INVISIBLE);
                    mUserList = response.body();
                    userListAdapter.updateData(response.body(), activity_userlist.this);
                }
            }
            @Override
            public void onFailure(Call<ArrayList<User>> call, Throwable t) {
                Log.d("debug","from here");
                Toast.makeText(activity_userlist.this,"Error, Mohon Coba Lagi",Toast.LENGTH_LONG).show();
                finish();
            }
        });

    }
}