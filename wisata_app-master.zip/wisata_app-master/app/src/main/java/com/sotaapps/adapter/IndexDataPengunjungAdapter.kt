package com.sotaapps.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sotaapps.R
import com.sotaapps.adapter.IndexDataPengunjungAdapter.ActivityViewHolder
import com.sotaapps.connection.API
import com.sotaapps.model.User
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_menu_user.*
import java.util.*


class IndexDataPengunjungAdapter(tempData: ArrayList<User>) :
    RecyclerView.Adapter<ActivityViewHolder?>() {
    var datasSet: ArrayList<User>
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ActivityViewHolder {
        val itemView: View = LayoutInflater.from(parent.context)
            .inflate(R.layout.activity_index_data_pengunjung_row, parent, false)
        return ActivityViewHolder(
            itemView
        )
    }

    @SuppressLint("ResourceAsColor")
    override fun onBindViewHolder(
        holder: ActivityViewHolder,
        position: Int
    ) {
        val user: User = datasSet[position]
        holder.nama.text = user.nama
        holder.alamat.text = "Alamat : " + user.alamat
        holder.nohp.text = "No Telp : " + user.noHp
        holder.tvAntrian.text = "No Antrian : " + user.nomorAntrian

        if (user.foto_diri != null){
            Picasso.with(holder.foto.context)
                .load(API.baseURLImage + user.foto_diri)
                .into(holder.foto)
            holder.foto_default.visibility = View.GONE
            holder.foto.visibility = View.VISIBLE
        }

    }


    class ActivityViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var nama: TextView
        var alamat: TextView
        var nohp: TextView
        var tvAntrian: TextView
        lateinit var foto_default: ImageView
        lateinit var foto: ImageView



        init {
            nama = itemView.findViewById(R.id.tvNama)
            alamat = itemView.findViewById(R.id.tvAlamat)
            nohp = itemView.findViewById(R.id.tvNomorHp)
            tvAntrian = itemView.findViewById(R.id.tvAntrian)
            foto_default = itemView.findViewById(R.id.user_photo_default)
            foto = itemView.findViewById(R.id.user_photo)
        }
    }

    init {
        datasSet = tempData
    }

    override fun getItemCount(): Int {
        return datasSet.size
    }
}