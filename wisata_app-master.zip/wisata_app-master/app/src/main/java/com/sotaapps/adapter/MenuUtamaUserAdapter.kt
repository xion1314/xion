package com.sotaapps.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.sotaapps.R
import com.sotaapps.activities.DetailWisataActivity
import com.sotaapps.activities.MenuUtamaUserActivity
import com.sotaapps.connection.API
import com.sotaapps.model.Wisata
import com.sotaapps.utils.RecyclerViewClickListener
import com.squareup.picasso.Picasso
import java.util.*


class MenuUtamaUserAdapter(tempData: ArrayList<Wisata>) :
    RecyclerView.Adapter<MenuUtamaUserAdapter.ActivityViewHolder?>() {
    var datasSet: ArrayList<Wisata>
    lateinit var contex:Context
    var listener: RecyclerViewClickListener? = null

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ActivityViewHolder {
        val itemView: View = LayoutInflater.from(parent.context)
            .inflate(R.layout.activity_menu_utama_user_row, parent, false)

        return ActivityViewHolder(
            itemView
        )
    }

    @SuppressLint("ResourceAsColor")
    override fun onBindViewHolder(holder: ActivityViewHolder, position: Int) {
        val wisata: Wisata = datasSet[position]
        val photo = wisata.foto

        holder.deskripsi.text = wisata.deskripsi
        holder.judul.text = wisata.judul


        Picasso.with(holder.gambar.context)
            .load(API.baseURLImage + photo)
            .into(holder.gambar)

        holder.cardView.setOnClickListener {
            listener?.onItemClicked(it, wisata)
        }

    }


    class ActivityViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var gambar: ImageView
        var deskripsi: TextView
        var judul: TextView
        var cardView: CardView


        init {
            gambar = itemView.findViewById(R.id.ivGambarWisata)
            deskripsi = itemView.findViewById(R.id.tvDeskripsi)
            judul = itemView.findViewById(R.id.tvJudul)
            cardView = itemView.findViewById(R.id.cardview)
        }
    }

    init {
        datasSet = tempData
    }

    override fun getItemCount(): Int {
        return datasSet.size
    }


}