package com.sotaapps.adapter;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.sotaapps.R;
import com.sotaapps.activities.MenuUserActivity;
import com.sotaapps.activities.activity_userlist;
import com.sotaapps.connection.API;
import com.sotaapps.model.User;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class userListAdapter extends RecyclerView.Adapter<userListAdapter.holder> {
    private List<User> userToBeShow = new ArrayList<>();
    Context mContext;

    @NonNull
    @Override
    public holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.container_userlist, parent, false);
        return new holder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull holder holder, int position) {
        final User toBeShow = userToBeShow.get(position);
            if(toBeShow.getFoto_diri().isEmpty()){
                Picasso.with(mContext).load(API.INSTANCE.getBaseURLImage() +"FOTO_EMPTY.jpg").into(holder.vw_User);
            }
            else {
                Picasso.with(mContext).load(API.INSTANCE.getBaseURLImage() + toBeShow.getFoto_diri()).into(holder.vw_User);
            }

            holder.txt_namaUser.setText(toBeShow.getNama());
            holder.txt_alamatUser.setText(toBeShow.getEmail());
            holder.txt_negaraUser.setText(toBeShow.getCountryOrigin());
            holder.btn_edt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(mContext, MenuUserActivity.class);
                    i.putExtra("mode", toBeShow.getId());
                    mContext.startActivity(i);
                }
            });
            holder.btn_delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String val = toBeShow.getId();
                    API.INSTANCE.delete_user(val).enqueue(new Callback<User>() {
                        @Override
                        public void onResponse(Call<User> call, Response<User> response) {
                            if(response.code() == 200){
                                API.INSTANCE.getAllUserInfo().enqueue(new Callback<ArrayList<User>>() {
                                    @Override
                                    public void onResponse(Call<ArrayList<User>> call, Response<ArrayList<User>> response) {
                                        if(response.code() == 200){
                                            updateData(response.body(), mContext);
                                        }
                                    }
                                    @Override
                                    public void onFailure(Call<ArrayList<User>> call, Throwable t) {
                                    }
                                });
                            }
                            Log.d("a","a");
                        }

                        @Override
                        public void onFailure(Call<User> call, Throwable t) {
                            Log.d("a","a");
                        }
                    });
                }
            });

    }

    @Override
    public int getItemCount() {
        return userToBeShow.size();
    }

    public void updateData(List<User> userToBeShow, Context mContext) {
        this.userToBeShow = userToBeShow;
        this.mContext = mContext;
        notifyDataSetChanged();
    }

    static class holder extends RecyclerView.ViewHolder {
        private TextView txt_namaUser, txt_alamatUser, txt_negaraUser;
        private ImageView vw_User;
        private Button btn_edt, btn_delete;

        public holder(@NonNull View itemView) {
            super(itemView);

            txt_namaUser = itemView.findViewById(R.id.txt_namaUser);
            txt_alamatUser = itemView.findViewById(R.id.txt_alamatUser);
            txt_negaraUser = itemView.findViewById(R.id.txt_negaraUser);
            vw_User = itemView.findViewById(R.id.vw_imageUser);
            btn_edt = itemView.findViewById(R.id.btn_edt);
            btn_delete = itemView.findViewById(R.id.btn_delete);
        }
    }
}


