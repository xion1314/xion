package com.sotaapps.connection

import android.graphics.Bitmap
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.sotaapps.activities.AddImageActivity
import com.sotaapps.activities.MenuUserActivity
import com.sotaapps.model.User
import com.sotaapps.model.Wisata
import okhttp3.*
import okhttp3.Headers
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.converter.scalars.ScalarsConverterFactory
import retrofit2.http.*
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.util.concurrent.TimeUnit

object API {
    var baseURL = "https://wasur.herokuapp.com/"
    var baseURLImage = "https://wasur.herokuapp.com/files/"
    //var baseURL = "http://192.168.1.66:3000/"
    //var baseURLImage = "http://192.168.1.66:3000/"
    var retrofit: Retrofit? = null
    val instance: Retrofit?
        get() {
            if (retrofit == null) {
                val interceptor = HttpLoggingInterceptor()
                interceptor.level = HttpLoggingInterceptor.Level.BODY
                val client = OkHttpClient.Builder()
                    .addInterceptor(interceptor)
                    .readTimeout(60, TimeUnit.SECONDS)
                    .connectTimeout(60, TimeUnit.SECONDS)
                    .build()
                val gson = GsonBuilder().setLenient().create()
                retrofit = Retrofit.Builder()
                    .baseUrl(baseURL)
                    .client(client)
                    .addConverterFactory(ScalarsConverterFactory.create())
                    .addConverterFactory(GsonConverterFactory.create(gson))
                    .build()
            }
            return retrofit
        }

    // This method converts Bitmap to RequestBody
    private fun toImageRequestBody(
        bitmap: Bitmap,
        name: String,
        fileName: String,
        type: String
    ): MultipartBody.Part {
        val bos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 0 /*ignored for PNG*/, bos)
        val bitmapdata = bos.toByteArray()
        val photo = RequestBody.create(MediaType.parse("multipart/form-data"), bitmapdata)
        return MultipartBody.Part.create(
            Headers.of(
                "Content-Disposition",
                "form-data; name=\"$name\"; filename=\"$fileName\"\r\nContent-Type: $type\r\n\r\n\r\n"
            ), photo
        )
    }

    // This method  converts Bitmap to RequestBody
    fun toInputStreamRequestBody(
        stream: InputStream,
        name: String,
        fileName: String,
        type: String
    ): MultipartBody.Part? {
        val buf: ByteArray
        try {
            buf = ByteArray(stream.available())
            while (stream.read(buf) != -1);
            val photo = RequestBody.create(MediaType.parse("multipart/form-data"), buf)
            return MultipartBody.Part.create(
                Headers.of(
                    "Content-Disposition",
                    "form-data; name=\"$name\"; filename=\"$fileName\"\r\nContent-Type: $type\r\n\r\n\r\n"
                ), photo
            )
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return null
    }

    private fun toTextRequestBody(value: String, name: String): MultipartBody.Part {
        return MultipartBody.Part.create(
            Headers.of(
                "Content-Disposition",
                "form-data; name=\"$name\""
            ),
            RequestBody.create(MediaType.parse("text/plain"), value)
        )
    }

    fun getUser(id: String?): Call<ArrayList<User>> {
        val service = instance!!.create(
            SotaService::class.java
        )
        return service.getUser(id)
    }

    fun validasiUsername(username: String?): Call<ArrayList<User>> {
        val service = instance!!.create(
            SotaService::class.java
        )
        return service.validasiUsername(username)
    }


    /*User*/

    fun updateMenuUser(
        user: User,
        fileUploads: ArrayList<File>
    ): Call<User> {
        val service = instance!!.create(SotaService::class.java)
        val requestBody = ArrayList<MultipartBody.Part>()
        requestBody.add(toTextRequestBody(Gson().toJson(user), "data"))
        val partDiri = RequestBody.create(MediaType.parse("multipart/form-data"),fileUploads[0])
        val partKtp = RequestBody.create(MediaType.parse("multipart/form-data"),fileUploads[1])
        requestBody.add(MultipartBody.Part.createFormData("foto_diri", fileUploads[0].name,partDiri))
        requestBody.add(MultipartBody.Part.createFormData("foto_ktp", fileUploads[1].name,partKtp))

        return service.updateMenuUser(requestBody)
    }

    fun insertWisata(
        wisata: Wisata,
        fileUploads: ArrayList<AddImageActivity.FileUpload>
    ): Call<Wisata> {
        val service = instance!!.create(SotaService::class.java)
        val requestBody = ArrayList<MultipartBody.Part>()
        requestBody.add(toTextRequestBody(Gson().toJson(wisata), "data"))
        for (fileUpload in fileUploads) {
            requestBody.add(
                toImageRequestBody(
                    fileUpload.bitmap,
                    fileUpload.fileName,
                    fileUpload.fileName,
                    fileUpload.type
                )
            )
        }
        return service.insertWisata(requestBody)
    }

    fun doRegister(user: User?, fileDiri: File?, fileKTP:File?): Call<User> {
        val requestBody = ArrayList<MultipartBody.Part>()
        val partDiri = RequestBody.create(MediaType.parse("multipart/form-data"),fileDiri)
        val partKtp = RequestBody.create(MediaType.parse("multipart/form-data"),fileKTP)
        requestBody.add(toTextRequestBody(Gson().toJson(user), "data"))
        requestBody.add(MultipartBody.Part.createFormData("foto_diri", fileDiri?.name,partDiri))
        requestBody.add(MultipartBody.Part.createFormData("foto_ktp", fileKTP?.name,partKtp))
        val service = instance!!.create(
            SotaService::class.java
        )
        return service.doRegister(requestBody)
    }

    fun doLogin(loginUser: User?): Call<User> {
        val service = instance!!.create(
            SotaService::class.java
        )
        return service.doLogin(loginUser)
    }

    fun getDetailWisara(id: String?): Call<ArrayList<Wisata>> {
        val service = instance!!.create(
            SotaService::class.java
        )
        return service.getDetailWisata(id)
    }

    fun getAntrianUser(id: String?): Call<ArrayList<User>> {
        val service = instance!!.create(
            SotaService::class.java
        )
        return service.getAntrianUser(id)
    }

    /*Admin*/

    fun getReport(periode: String?, date: String?): Call<ArrayList<User>> {
        val service = instance!!.create(
            SotaService::class.java
        )
        return service.getReport(periode, date)
    }

    fun addDataPengunjung(user: User?): Call<User> {
        val service = instance!!.create(
            SotaService::class.java
        )
        return service.addDataPengunjung(user)
    }

    fun getAllUser(): Call<ArrayList<User>> {
        val service = instance!!.create(
            SotaService::class.java
        )
        return service.getAllUser()
    }

    fun getAllUserInfo(): Call<ArrayList<User>> {
        val service = instance!!.create(
            SotaService::class.java
        )
        return service.getAllUserInfo()
    }

    fun getAllWisata(): Call<ArrayList<Wisata>> {
        val service = instance!!.create(
            SotaService::class.java
        )
        return service.getAllWisata()
    }

    fun delete_user(id:String): Call<User> {
        val service = instance!!.create(
            SotaService::class.java
        )
        return service.delUser(id)
    }


    interface SotaService {
        @GET("api_get_detail_user")
        fun getUser(@Query("id") id: String?): Call<ArrayList<User>>

        @DELETE("api_delete_user")
        fun delUser(@Query("id") id: String?):Call<User>

        @GET("api_validasi_username")
        fun validasiUsername(@Query("username") username: String?): Call<ArrayList<User>>

        /*User*/

        @Multipart
        @POST("api_user_update_menu_user")
        fun updateMenuUser(@Part params: List<MultipartBody.Part?>?): Call<User>

        @Multipart
        @POST("api_insert_wisata")
        fun insertWisata(@Part params: List<MultipartBody.Part?>?): Call<Wisata>

        @GET("api_user_get_detail_wisata")
        fun getDetailWisata(@Query("id") id: String?): Call<ArrayList<Wisata>>

        @GET("api_user_get_antrian")
        fun getAntrianUser(@Query("id") id: String?): Call<ArrayList<User>>

        /*Admin*/
        @GET("api_admin_get_report_pengunjung")
        fun getReport(
            @Query("periode") code_sj: String?,
            @Query("date") flag: String?
        ): Call<ArrayList<User>>

        @POST("api_admin_tambah_data_pengunjung")
        fun addDataPengunjung(@Body user: User?): Call<User>

        @Multipart
        @POST("api_user_register")
        fun doRegister(@Part params: List<MultipartBody.Part?>?): Call<User>

        @POST("api_login")
        fun doLogin(@Body loginUser: User?): Call<User>

        @GET("api_admin_get_all_user")
        fun getAllUser(): Call<ArrayList<User>>

        @GET("api_admin_get_all_user_info")
        fun getAllUserInfo(): Call<ArrayList<User>>

        @GET("api_admin_get_all_wisata")
        fun getAllWisata(): Call<ArrayList<Wisata>>

    }
}