package com.sotaapps.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import java.io.File

class User {
    @SerializedName("id")
    @Expose
    var id: String? = null

    @SerializedName("nama")
    @Expose
    var nama: String? = null

    @SerializedName("username")
    @Expose
    var username: String? = null

    @SerializedName("password")
    @Expose
    var password: String? = null

    @SerializedName("alamat")
    @Expose
    var alamat: String? = null

    @SerializedName("email")
    @Expose
    var email: String? = null

    @SerializedName("asal_negara")
    @Expose
    var CountryOrigin: String? = null

    @SerializedName("no_hp")
    @Expose
    var noHp: String? = null

    @SerializedName("jenis_kelamin")
    @Expose
    var jenisKelamin: String? = null

    @SerializedName("nomor_antrian")
    @Expose
    var nomorAntrian: Int? = null

    @SerializedName("keperluan")
    @Expose
    var keperluan: String? = null

    @SerializedName("group_id")
    @Expose
    var groupId: String? = null

    @SerializedName("group_title")
    @Expose
    var groupTitle: String? = null

    @SerializedName("created_at")
    @Expose
    var createdAt: String? = null

    @SerializedName("created_by")
    @Expose
    var createdBy: String? = null

    @SerializedName("foto_diri")
    @Expose
    var foto_diri: String? = null

    @SerializedName("foto_ktp")
    @Expose
    var foto_ktp: String? = null

    @SerializedName("modi_at")
    @Expose
    var modiAt: String? = null

    @SerializedName("modi_by")
    @Expose
    var modiBy: String? = null

    @SerializedName("status")
    @Expose
    var status: String? = null

    @SerializedName("foto")
    @Expose
    var foto: String? = null

    @SerializedName("user_id")
    @Expose
    var userId: String? = null
}