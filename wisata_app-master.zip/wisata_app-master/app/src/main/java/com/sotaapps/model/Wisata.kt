package com.sotaapps.model

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName


class Wisata {
    @SerializedName("id")
    @Expose
    var id: String? = null

    @SerializedName("foto")
    @Expose
    var foto: String? = null

    @SerializedName("judul")
    @Expose
    var judul: String? = null

    @SerializedName("deskripsi")
    @Expose
    var deskripsi: String? = null

    @SerializedName("created_at")
    @Expose
    var createdAt: String? = null

    @SerializedName("created_by")
    @Expose
    var createdBy: String? = null

    @SerializedName("modi_at")
    @Expose
    var modiAt: Any? = null

    @SerializedName("modi_by")
    @Expose
    var modiBy: Any? = null

}