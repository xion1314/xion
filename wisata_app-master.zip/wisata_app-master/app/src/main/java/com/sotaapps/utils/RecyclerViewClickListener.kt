package com.sotaapps.utils

import android.view.View
import com.sotaapps.model.Wisata

interface RecyclerViewClickListener {

    // method yang akan dipanggil di MainActivity
    fun onItemClicked(view: View, wisata: Wisata)

}